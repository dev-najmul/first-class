



 let marks = prompt('Put your marks');



 if( marks >= 0 && marks < 32){
          console.log(`Apni faill korsen... akhon muri khan`);
 }else if( marks >= 33 && marks < 40){
      console.log(`Apni D paisen... akhon misty khaoan`);
}else if( marks >= 40 && marks < 50){
      console.log(`Apni c paisen... akhon misty khaoan`);
}else if( marks >= 50 && marks < 60){
      console.log(`Apni C paisen... akhon misty khaoan`);
}else if( marks >= 60 && marks < 70){
      console.log(`Apni A- paisen... akhon misty khaoan`);
}else if( marks >= 70 && marks < 80){
      console.log(`Apni A paisen... akhon misty khaoan`);
}else if( marks >= 80 && marks <= 100){
      console.log(`WOW Apni A+ paisen... akhon misty khaoan`);
}else{
      console.log('apni mia pagol naki');
}