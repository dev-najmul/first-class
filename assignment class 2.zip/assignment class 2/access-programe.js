


   let age = prompt('Pur your age plz');



   if ( age >= 20 && age < 35){
         console.log(`welcome Vai amra apnar jonno e wait korteselam.`);

   }else if ( age > 35){
      console.log(` Sorry vai ata apnar jonno na.`);
   }else{
         console.log(' Tumi akhono soto boro hoiya aiso.');
   }

